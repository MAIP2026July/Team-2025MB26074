import io, random, yaml
import numpy as np, streamlit as st
from PIL import Image
import audit
from classifier import load_classifier, image_quality
from routing import decide_route

cfg = yaml.safe_load(open("config.yaml"))
st.set_page_config(page_title="CardamomLens", layout="wide")
st.title("CardamomLens — quality-screening copilot")
st.warning("Screening category only — **not an official AGMARK grade**. The human grader decides the official grade.")

@st.cache_resource
def _clf(): return load_classifier(cfg)
clf, demo = _clf()
if demo: st.info("DEMO mode: no trained model found. Predictions come from a colour/darkness rules heuristic, not AI.")

with st.sidebar:
    site = st.text_input("Site", "Demo site"); grader = st.text_input("Grader ID", "grader-1")
    st.caption(f"Model: {clf.name} · v{cfg['model_version']}")
    with st.expander("Active thresholds"):
        st.json({k: cfg[k] for k in ["accept_confidence", "min_margin", "min_brightness", "min_sharpness", "blind_mode_rate"]})

c1, c2 = st.columns(2)
sample_id = c1.text_input("Sample ID", "S-0001"); lot_id = c2.text_input("Lot ID", "L-001")
up = st.file_uploader("Photo of cardamom sample (plain background, even light)", type=["jpg", "jpeg", "png"])

if up:
    raw = up.getvalue(); img = Image.open(io.BytesIO(raw)).convert("RGB")
    key = audit.sha(raw)
    if st.session_state.get("key") != key:
        st.session_state.key = key
        st.session_state.blind = random.random() < cfg["blind_mode_rate"]
        ok, q = image_quality(img, cfg)
        try:
            probs, cam = clf.predict(img)
        except Exception as e:
            st.error(f"Model error: {e}. Manual-only mode."); probs, cam = {}, None
        st.session_state.res = (ok, q, probs, cam, decide_route(probs, ok, cfg))
        st.session_state.saved = False
    ok, q, probs, cam, route = st.session_state.res
    blind = st.session_state.blind

    a, b = st.columns(2)
    a.image(img, caption="Sample", use_container_width=True)
    if cam is not None and not blind:
        h = np.asarray(Image.fromarray((cam * 255).astype("uint8")).resize(img.size))[..., None] / 255.0
        over = (np.asarray(img) * (1 - 0.5 * h) + np.array([255, 0, 0]) * 0.5 * h).astype("uint8")
        b.image(over, caption="Grad-CAM: regions driving the prediction", use_container_width=True)
    else:
        b.caption("No heatmap in DEMO mode / blind mode.")
    if not ok: st.error(f"Image quality low {q} — please retake.")

    human_default = None
    if blind:
        st.info("Blind mode: record your own category first.")
        human_default = st.radio("Your category", cfg["classes"], index=None, key="blind_cat")
    if not blind or human_default:
        ranked = sorted(probs.items(), key=lambda kv: -kv[1])
        if ranked:
            st.subheader(f"{ranked[0][0]} — confidence {route.confidence_band} ({ranked[0][1]:.2f})")
            st.bar_chart(probs)
        if route.action == "ACCEPT_FOR_SCREENING": st.success("✅ Recommendation: ACCEPT FOR SCREENING")
        else: st.error("🔍 Recommendation: MANUAL REVIEW REQUIRED")
        for r in route.reasons: st.write("• " + r)

        st.markdown("### Your decision")
        ai_top = ranked[0][0] if ranked else ""
        human = st.radio("Final screening category", cfg["classes"],
                         index=cfg["classes"].index(ai_top) if (ai_top and route.action == "ACCEPT_FOR_SCREENING") else None,
                         key="human")
        reason = st.text_input("Reason (required for review cases and any override)")
        followed = bool(human) and human == ai_top
        needs_reason = route.action == "MANUAL_REVIEW" or not followed
        if st.button("Save decision", disabled=st.session_state.saved):
            if not human: st.error("Choose a category.")
            elif needs_reason and not reason.strip(): st.error("A reason is required.")
            else:
                audit.append(cfg["audit_log_path"], dict(
                    grader=grader, site=site, sample_id=sample_id, lot_id=lot_id, image_sha256=key,
                    model_version=cfg["model_version"], backend=clf.name,
                    probs={k: round(v, 3) for k, v in probs.items()}, ai_top=ai_top,
                    ai_confidence=round(ranked[0][1], 3) if ranked else "", route=route.action,
                    route_reasons="; ".join(route.reasons), human_category=human,
                    followed_ai=followed, reason=reason, blind_mode=blind))
                st.session_state.saved = True; st.success("Saved to audit log.")

st.divider(); st.subheader("Audit log")
try:
    import pandas as pd; st.dataframe(pd.read_csv(cfg["audit_log_path"]).tail(20))
except Exception:
    st.caption("No decisions logged yet.")
