import csv, hashlib, os, datetime
FIELDS = ["timestamp", "grader", "site", "sample_id", "lot_id", "image_sha256", "model_version",
          "backend", "probs", "ai_top", "ai_confidence", "route", "route_reasons",
          "human_category", "followed_ai", "reason", "blind_mode"]

def sha(b: bytes) -> str: return hashlib.sha256(b).hexdigest()[:16]

def append(path, row: dict):
    new = not os.path.exists(path)
    row = {"timestamp": datetime.datetime.now().isoformat(timespec="seconds"), **row}
    with open(path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS); 
        if new: w.writeheader()
        w.writerow({k: row.get(k, "") for k in FIELDS})
