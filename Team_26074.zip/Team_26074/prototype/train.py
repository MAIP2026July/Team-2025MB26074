"""Transfer-learning script. Expects data/{train,val}/<class_name>/*.jpg
Usage: python train.py --data data --epochs 8
Reports macro-F1, per-class recall, ECE and fits a temperature on the val set.
NOTE: results are only meaningful with an expert-labelled, representative validation set."""
import argparse, numpy as np, torch, torchvision as tv, yaml
from sklearn.metrics import f1_score, classification_report

ap = argparse.ArgumentParser(); ap.add_argument("--data", default="data"); ap.add_argument("--epochs", type=int, default=8)
a = ap.parse_args(); cfg = yaml.safe_load(open("config.yaml"))
norm = tv.transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
tr_t = tv.transforms.Compose([tv.transforms.Resize((224, 224)), tv.transforms.RandomHorizontalFlip(),
        tv.transforms.ColorJitter(0.3, 0.3, 0.2), tv.transforms.ToTensor(), norm])  # lighting robustness
va_t = tv.transforms.Compose([tv.transforms.Resize((224, 224)), tv.transforms.ToTensor(), norm])
tr = tv.datasets.ImageFolder(f"{a.data}/train", tr_t); va = tv.datasets.ImageFolder(f"{a.data}/val", va_t)
assert tr.classes == sorted(cfg["classes"]) or set(tr.classes) == set(cfg["classes"]), f"classes mismatch: {tr.classes}"
cfg["classes"] = tr.classes  # keep ImageFolder order
m = tv.models.mobilenet_v2(weights=tv.models.MobileNet_V2_Weights.DEFAULT)
for p in m.features.parameters(): p.requires_grad = False
m.classifier[1] = torch.nn.Linear(m.last_channel, len(tr.classes))
opt = torch.optim.Adam(m.classifier.parameters(), 1e-3); lf = torch.nn.CrossEntropyLoss()
dl = torch.utils.data.DataLoader(tr, 32, shuffle=True); vl = torch.utils.data.DataLoader(va, 64)
for ep in range(a.epochs):
    m.train()
    for x, y in dl: opt.zero_grad(); lf(m(x), y).backward(); opt.step()
    print("epoch", ep + 1, "done")
m.eval(); L, Y = [], []
with torch.no_grad():
    for x, y in vl: L.append(m(x)); Y.append(y)
L, Y = torch.cat(L), torch.cat(Y)
T = torch.nn.Parameter(torch.ones(1)); o = torch.optim.LBFGS([T], lr=0.1, max_iter=50)
def closure(): o.zero_grad(); l = lf(L / T, Y); l.backward(); return l
o.step(closure)
P = torch.softmax(L / T.detach(), 1); pred = P.argmax(1)
conf = P.max(1).values; acc = (pred == Y).float()
bins = torch.linspace(0, 1, 11); ece = 0.0
for i in range(10):
    s = (conf > bins[i]) & (conf <= bins[i + 1])
    if s.any(): ece += s.float().mean() * abs(acc[s].mean() - conf[s].mean())
print(classification_report(Y, pred, target_names=tr.classes))
print("macro-F1:", f1_score(Y, pred, average="macro"), "ECE:", float(ece), "T:", float(T))
torch.save({"state_dict": m.state_dict(), "temperature": float(T), "classes": tr.classes}, "models/cardamomlens.pt")
