"""Deterministic confidence-routing logic. Pure functions -> easy to test and audit."""
from dataclasses import dataclass

@dataclass
class Route:
    action: str          # "ACCEPT_FOR_SCREENING" or "MANUAL_REVIEW"
    reasons: list
    confidence_band: str # HIGH / MEDIUM / LOW

def decide_route(probs: dict, quality_ok: bool, cfg: dict) -> Route:
    if not probs:
        return Route("MANUAL_REVIEW", ["model unavailable"], "LOW")
    ranked = sorted(probs.items(), key=lambda kv: kv[1], reverse=True)
    (top, p1), p2 = ranked[0], (ranked[1][1] if len(ranked) > 1 else 0.0)
    margin = p1 - p2
    reasons = []
    if not quality_ok:
        reasons.append("poor image quality")
    if top in cfg["defect_classes"]:
        reasons.append(f"predicted defect class: {top}")
    if p1 < cfg["accept_confidence"]:
        reasons.append(f"confidence {p1:.2f} < {cfg['accept_confidence']}")
    if margin < cfg["min_margin"]:
        reasons.append(f"top-2 margin {margin:.2f} < {cfg['min_margin']}")
    band = "HIGH" if p1 >= cfg["accept_confidence"] else ("MEDIUM" if p1 >= cfg.get("medium_confidence", 0.6) else "LOW")
    if reasons:
        return Route("MANUAL_REVIEW", reasons, band)
    return Route("ACCEPT_FOR_SCREENING", ["confidence and margin above thresholds, no defect signal"], band)
