import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from routing import decide_route
CFG = {"defect_classes": ["Defective"], "accept_confidence": 0.85, "min_margin": 0.2}
def P(**k): return k

def test_high_conf_standard_accepts():
    r = decide_route(P(Premium=0.05, Standard=0.9, Low_Grade=0.03, Defective=0.02), True, CFG)
    assert r.action == "ACCEPT_FOR_SCREENING" and r.confidence_band == "HIGH"

def test_defect_always_review_even_when_confident():
    r = decide_route(P(Premium=0.0, Standard=0.02, Low_Grade=0.02, Defective=0.96), True, CFG)
    assert r.action == "MANUAL_REVIEW"

def test_low_confidence_review():
    r = decide_route(P(Premium=0.4, Standard=0.35, Low_Grade=0.15, Defective=0.1), True, CFG)
    assert r.action == "MANUAL_REVIEW"

def test_poor_quality_review():
    r = decide_route(P(Premium=0.05, Standard=0.9, Low_Grade=0.03, Defective=0.02), False, CFG)
    assert r.action == "MANUAL_REVIEW" and "poor image quality" in r.reasons

def test_no_model_never_accepts():
    assert decide_route({}, True, CFG).action == "MANUAL_REVIEW"
