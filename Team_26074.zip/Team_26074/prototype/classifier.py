"""Classifier backends.
 - TorchClassifier: trained MobileNetV2 (+Grad-CAM) if models/cardamomlens.pt exists.
 - HeuristicClassifier: DEMO / rules baseline. NOT an AI model; used to show the workflow
   and as the 'simple rules' baseline the real model must beat.
"""
import os
import numpy as np
from PIL import Image

def image_quality(img: Image.Image, cfg: dict):
    g = np.asarray(img.convert("L"), dtype=float)
    brightness = g.mean()
    gy, gx = np.gradient(g)
    sharp = float((gx ** 2 + gy ** 2).var() ** 0.5 / 10)
    ok = brightness >= cfg["min_brightness"] and sharp >= cfg["min_sharpness"]
    return ok, {"brightness": round(float(brightness), 1), "sharpness": round(sharp, 2)}

def _softmax(x):
    e = np.exp(x - np.max(x)); return e / e.sum()

class HeuristicClassifier:
    name = "DEMO heuristic (rules baseline, not AI)"
    def __init__(self, classes): self.classes = classes
    def predict(self, img):
        a = np.asarray(img.convert("RGB").resize((224, 224)), dtype=float)
        r, g, b = a[..., 0], a[..., 1], a[..., 2]
        bright = a.mean(axis=2)
        green = float(((g > r * 1.02) & (g > b * 1.05)).mean())
        dark = float((bright < 60).mean())
        score = {
            "Premium": 4 * green - 6 * dark,
            "Standard": 2 * green - 3 * dark + 0.5,
            "Low_Grade": 1.0 - 2 * green + 2 * dark,
            "Defective": 8 * dark - 1 * green,
        }
        p = _softmax(np.array([score[c] for c in self.classes]) * 2.0)
        return dict(zip(self.classes, map(float, p))), None

class TorchClassifier:
    name = "MobileNetV2 transfer-learned"
    def __init__(self, path, classes):
        import torch, torchvision
        self.torch, self.classes = torch, classes
        m = torchvision.models.mobilenet_v2(weights=None)
        m.classifier[1] = torch.nn.Linear(m.last_channel, len(classes))
        ck = torch.load(path, map_location="cpu")
        m.load_state_dict(ck["state_dict"]); m.eval()
        self.model, self.T = m, float(ck.get("temperature", 1.0))  # temperature scaling
        self.tf = torchvision.transforms.Compose([
            torchvision.transforms.Resize((224, 224)), torchvision.transforms.ToTensor(),
            torchvision.transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
    def predict(self, img):
        torch = self.torch
        x = self.tf(img.convert("RGB")).unsqueeze(0)
        feats, grads = [], []
        h1 = self.model.features[-1].register_forward_hook(lambda m, i, o: feats.append(o))
        h2 = self.model.features[-1].register_full_backward_hook(lambda m, gi, go: grads.append(go[0]))
        logits = self.model(x) / self.T
        probs = torch.softmax(logits, 1)[0]
        self.model.zero_grad(); logits[0, int(probs.argmax())].backward()
        h1.remove(); h2.remove()
        w = grads[0].mean(dim=(2, 3), keepdim=True)
        cam = torch.relu((w * feats[0]).sum(1))[0].detach().numpy()
        cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
        return dict(zip(self.classes, map(float, probs.detach()))), cam

def load_classifier(cfg):
    if os.path.exists(cfg["model_path"]):
        try:
            return TorchClassifier(cfg["model_path"], cfg["classes"]), False
        except Exception as e:  # fall back safely, never silently pretend
            print("Model load failed:", e)
    return HeuristicClassifier(cfg["classes"]), True
