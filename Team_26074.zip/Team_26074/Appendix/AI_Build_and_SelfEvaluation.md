# AI Build + Self-Evaluation (Instruction #4)

> **Transparency:** the evaluation below was produced by Claude in the same session that drafted the artifacts, so it is *not independent*. **Action for Avinash:** paste the markdown artifacts into a *second* AI (ChatGPT/Gemini) with the two prompts below and append its output under "Second-AI run".

## Prompts to give any AI (with the whole repo's .md files attached)
**Prompt 1 — Build:** "Using only these PM artifacts (PRD, workflow, metrics, roadmap, risk note), build the product described. State every assumption you had to make because the artifacts were silent."
**Prompt 2 — Self-evaluation:** "Critique the artifacts: (a) ambiguities or contradictions, (b) missing requirements, (c) what you had to hard-code vs what should be configurable, (d) changes you recommend. Rank by severity."

## Run 1 — Claude (same-session) 
### Build outcome
Built `prototype/` (Streamlit app, routing, classifier backends, audit log, training script, 5 passing unit tests). Everything specified in PRD F1, F3–F9 is implemented; F2 partly (brightness/sharpness gate); **F10 blind mode implemented minimally; F11 PDF report not built.**

### Ambiguities found in the artifacts
| # | Ambiguity | How it was resolved in build | Severity |
|---|---|---|---|
| 1 | Four class names are placeholders; no definition of "Low_Grade" vs "Defective" | Assumed 4 classes in config | High |
| 2 | "Boundary case" never defined | Defined as top-2 margin < 0.20 (config) | High |
| 3 | "Accept" wording: users may read it as "grade accepted" | Renamed to *Accept-for-screening*; banner added | Medium |
| 4 | Should a human confirmation be needed on Accept? | Yes — logged on confirm; no auto-finalise | Medium |
| 5 | Who is user of supervisor queue; no screen built | Out of MVP; audit table shown | Low |
| 6 | Metrics targets (+10 pts F1, 2% FA) lack justification | Kept, flagged as assumptions | Medium |
| 7 | Revenue figures (₹) are unsupported guesses | Marked (A); validate in Phase 0 | High |
| 8 | Final report says "Premium/Standard/..." but approval form says categories ≠ AGMARK; no mapping plan | Listed as G3 study | High |

### Hard-coded vs configurable
| Item | Before self-review | After |
|---|---|---|
| Accept confidence, margin, quality thresholds, defect classes, class list, paths | config.yaml | ✅ configurable |
| MEDIUM confidence band (0.6) | hard-coded in routing.py | ✅ moved to config (`medium_confidence`) |
| Heuristic constants (green/dark weights) in demo classifier | hard-coded | ⚠ left hard-coded; acceptable because it is a throw-away baseline — should be tuned/documented if used as the official rules baseline |
| Threshold selection | manual | ⚠ should be *derived* from validation set to hit the FA ceiling (script TODO) |
| Image size 224, augmentations, epochs | hard-coded in train.py | ⚠ move to config if experiments grow |
| Audit log CSV | hard-coded format | ⚠ replace with SQLite/DB for multi-user pilot |
| Auth / user roles | none (free-text grader ID) | ⚠ needed before pilot |

### Recommended changes (ranked)
1. Get expert-defined classes + gold-label sample **before** more build (blocks everything).
2. Add threshold-calibration script: pick accept threshold that meets FA ceiling on val set.
3. Add rules-baseline vs model comparison notebook so "Why AI" is evidence, not claim.
4. Add per-slice evaluation (lighting/camera) and drift report.
5. Re-do revenue numbers from interviews; add price-sensitivity range.
6. Build supervisor queue and lot-level PDF (revenue feature).
7. Add auth, retention policy, and consent text before any real data.

### Self-critique of this critique
It cannot test model accuracy (no data), cannot judge domain correctness of grade categories, and tends to be agreeable with its own artifacts — hence the independent second run.

## Second-AI run (to be pasted by Avinash)
*Tool:* ______  *Date:* ______
*Build outcome:* …
*Ambiguities / changes / hard-coded vs configurable:* …
*What I accepted / rejected and why:* …
